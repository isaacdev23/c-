﻿namespace AppBoteco
{
    partial class FrmVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmVenda));
            this.BtnLocalizar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.DgvPedido = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtIdProduto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtQuantidade = new System.Windows.Forms.TextBox();
            this.TxtValor = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BtnNovoiten = new System.Windows.Forms.Button();
            this.BtnEditariten = new System.Windows.Forms.Button();
            this.BtnExcluiritem = new System.Windows.Forms.Button();
            this.BtnNovopedido = new System.Windows.Forms.Button();
            this.BtnAtualizarpedido = new System.Windows.Forms.Button();
            this.BtnFinalizarpedido = new System.Windows.Forms.Button();
            this.BtnFinalizarvenda = new System.Windows.Forms.Button();
            this.BtnFechar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.LblEstoque = new System.Windows.Forms.Label();
            this.CpxCliente = new System.Windows.Forms.ComboBox();
            this.CpxProduto = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TxtTotal = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPedido)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnLocalizar
            // 
            this.BtnLocalizar.BackColor = System.Drawing.Color.Lime;
            this.BtnLocalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLocalizar.Location = new System.Drawing.Point(160, 21);
            this.BtnLocalizar.Name = "BtnLocalizar";
            this.BtnLocalizar.Size = new System.Drawing.Size(151, 32);
            this.BtnLocalizar.TabIndex = 0;
            this.BtnLocalizar.Text = "LOCALIZAR";
            this.BtnLocalizar.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "ID PEDIDO";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // DgvPedido
            // 
            this.DgvPedido.AllowUserToAddRows = false;
            this.DgvPedido.AllowUserToDeleteRows = false;
            this.DgvPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvPedido.Location = new System.Drawing.Point(12, 268);
            this.DgvPedido.Name = "DgvPedido";
            this.DgvPedido.ReadOnly = true;
            this.DgvPedido.Size = new System.Drawing.Size(557, 150);
            this.DgvPedido.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "CLIENTE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "PRODUTO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "ID PRODUTO";
            // 
            // TxtIdProduto
            // 
            this.TxtIdProduto.Location = new System.Drawing.Point(12, 164);
            this.TxtIdProduto.Name = "TxtIdProduto";
            this.TxtIdProduto.Size = new System.Drawing.Size(151, 20);
            this.TxtIdProduto.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 15);
            this.label5.TabIndex = 11;
            this.label5.Text = "QUANTIDADE";
            // 
            // TxtQuantidade
            // 
            this.TxtQuantidade.Location = new System.Drawing.Point(12, 203);
            this.TxtQuantidade.Name = "TxtQuantidade";
            this.TxtQuantidade.Size = new System.Drawing.Size(188, 20);
            this.TxtQuantidade.TabIndex = 12;
            // 
            // TxtValor
            // 
            this.TxtValor.Location = new System.Drawing.Point(12, 242);
            this.TxtValor.Name = "TxtValor";
            this.TxtValor.Size = new System.Drawing.Size(151, 20);
            this.TxtValor.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 226);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "VALOR R$";
            // 
            // BtnNovoiten
            // 
            this.BtnNovoiten.BackColor = System.Drawing.Color.Lime;
            this.BtnNovoiten.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNovoiten.Location = new System.Drawing.Point(418, 147);
            this.BtnNovoiten.Name = "BtnNovoiten";
            this.BtnNovoiten.Size = new System.Drawing.Size(151, 32);
            this.BtnNovoiten.TabIndex = 14;
            this.BtnNovoiten.Text = "NOVO ITEM";
            this.BtnNovoiten.UseVisualStyleBackColor = false;
            // 
            // BtnEditariten
            // 
            this.BtnEditariten.BackColor = System.Drawing.Color.Lime;
            this.BtnEditariten.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEditariten.Location = new System.Drawing.Point(418, 185);
            this.BtnEditariten.Name = "BtnEditariten";
            this.BtnEditariten.Size = new System.Drawing.Size(151, 32);
            this.BtnEditariten.TabIndex = 15;
            this.BtnEditariten.Text = "EDIÇÃO DE ITEM";
            this.BtnEditariten.UseVisualStyleBackColor = false;
            // 
            // BtnExcluiritem
            // 
            this.BtnExcluiritem.BackColor = System.Drawing.Color.Lime;
            this.BtnExcluiritem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExcluiritem.Location = new System.Drawing.Point(418, 226);
            this.BtnExcluiritem.Name = "BtnExcluiritem";
            this.BtnExcluiritem.Size = new System.Drawing.Size(151, 32);
            this.BtnExcluiritem.TabIndex = 16;
            this.BtnExcluiritem.Text = "EXCLUSÃO DE ITEM";
            this.BtnExcluiritem.UseVisualStyleBackColor = false;
            // 
            // BtnNovopedido
            // 
            this.BtnNovopedido.BackColor = System.Drawing.Color.Lime;
            this.BtnNovopedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNovopedido.Location = new System.Drawing.Point(623, 16);
            this.BtnNovopedido.Name = "BtnNovopedido";
            this.BtnNovopedido.Size = new System.Drawing.Size(151, 32);
            this.BtnNovopedido.TabIndex = 17;
            this.BtnNovopedido.Text = " NOVO PEDIDO";
            this.BtnNovopedido.UseVisualStyleBackColor = false;
            // 
            // BtnAtualizarpedido
            // 
            this.BtnAtualizarpedido.BackColor = System.Drawing.Color.Lime;
            this.BtnAtualizarpedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAtualizarpedido.Location = new System.Drawing.Point(623, 65);
            this.BtnAtualizarpedido.Name = "BtnAtualizarpedido";
            this.BtnAtualizarpedido.Size = new System.Drawing.Size(151, 32);
            this.BtnAtualizarpedido.TabIndex = 18;
            this.BtnAtualizarpedido.Text = "ATUALIZAR PEDIDO";
            this.BtnAtualizarpedido.UseVisualStyleBackColor = false;
            // 
            // BtnFinalizarpedido
            // 
            this.BtnFinalizarpedido.BackColor = System.Drawing.Color.Yellow;
            this.BtnFinalizarpedido.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnFinalizarpedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFinalizarpedido.Location = new System.Drawing.Point(592, 268);
            this.BtnFinalizarpedido.Name = "BtnFinalizarpedido";
            this.BtnFinalizarpedido.Size = new System.Drawing.Size(151, 32);
            this.BtnFinalizarpedido.TabIndex = 19;
            this.BtnFinalizarpedido.Text = "FINALIZAR PEDIDO";
            this.BtnFinalizarpedido.UseVisualStyleBackColor = false;
            // 
            // BtnFinalizarvenda
            // 
            this.BtnFinalizarvenda.BackColor = System.Drawing.Color.Yellow;
            this.BtnFinalizarvenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFinalizarvenda.Location = new System.Drawing.Point(592, 327);
            this.BtnFinalizarvenda.Name = "BtnFinalizarvenda";
            this.BtnFinalizarvenda.Size = new System.Drawing.Size(151, 32);
            this.BtnFinalizarvenda.TabIndex = 20;
            this.BtnFinalizarvenda.Text = "FINALIZAR VENDA";
            this.BtnFinalizarvenda.UseVisualStyleBackColor = false;
            // 
            // BtnFechar
            // 
            this.BtnFechar.BackColor = System.Drawing.Color.Red;
            this.BtnFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFechar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnFechar.Location = new System.Drawing.Point(592, 386);
            this.BtnFechar.Name = "BtnFechar";
            this.BtnFechar.Size = new System.Drawing.Size(151, 32);
            this.BtnFechar.TabIndex = 21;
            this.BtnFechar.Text = "BtnFechar";
            this.BtnFechar.UseVisualStyleBackColor = false;
            this.BtnFechar.Click += new System.EventHandler(this.button9_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(206, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 15);
            this.label6.TabIndex = 22;
            this.label6.Text = "ESTOQUE :";
            // 
            // LblEstoque
            // 
            this.LblEstoque.AutoSize = true;
            this.LblEstoque.Location = new System.Drawing.Point(292, 204);
            this.LblEstoque.Name = "LblEstoque";
            this.LblEstoque.Size = new System.Drawing.Size(35, 13);
            this.LblEstoque.TabIndex = 23;
            this.LblEstoque.Text = "label8";
            // 
            // CpxCliente
            // 
            this.CpxCliente.FormattingEnabled = true;
            this.CpxCliente.Location = new System.Drawing.Point(12, 78);
            this.CpxCliente.Name = "CpxCliente";
            this.CpxCliente.Size = new System.Drawing.Size(299, 21);
            this.CpxCliente.TabIndex = 24;
            // 
            // CpxProduto
            // 
            this.CpxProduto.FormattingEnabled = true;
            this.CpxProduto.Location = new System.Drawing.Point(12, 124);
            this.CpxProduto.Name = "CpxProduto";
            this.CpxProduto.Size = new System.Drawing.Size(299, 21);
            this.CpxProduto.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(367, 425);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 15);
            this.label9.TabIndex = 26;
            this.label9.Text = "TOTAL R$";
            // 
            // TxtTotal
            // 
            this.TxtTotal.Location = new System.Drawing.Point(444, 424);
            this.TxtTotal.Name = "TxtTotal";
            this.TxtTotal.Size = new System.Drawing.Size(125, 20);
            this.TxtTotal.TabIndex = 27;
            // 
            // FrmVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(822, 476);
            this.Controls.Add(this.TxtTotal);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.CpxProduto);
            this.Controls.Add(this.CpxCliente);
            this.Controls.Add(this.LblEstoque);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BtnFechar);
            this.Controls.Add(this.BtnFinalizarvenda);
            this.Controls.Add(this.BtnFinalizarpedido);
            this.Controls.Add(this.BtnAtualizarpedido);
            this.Controls.Add(this.BtnNovopedido);
            this.Controls.Add(this.BtnExcluiritem);
            this.Controls.Add(this.BtnEditariten);
            this.Controls.Add(this.BtnNovoiten);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TxtValor);
            this.Controls.Add(this.TxtQuantidade);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TxtIdProduto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DgvPedido);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnLocalizar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmVenda";
            this.Text = "Pedido / Venda";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.DgvPedido)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnLocalizar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView DgvPedido;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtIdProduto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TxtQuantidade;
        private System.Windows.Forms.TextBox TxtValor;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BtnNovoiten;
        private System.Windows.Forms.Button BtnEditariten;
        private System.Windows.Forms.Button BtnExcluiritem;
        private System.Windows.Forms.Button BtnNovopedido;
        private System.Windows.Forms.Button BtnAtualizarpedido;
        private System.Windows.Forms.Button BtnFinalizarpedido;
        private System.Windows.Forms.Button BtnFinalizarvenda;
        private System.Windows.Forms.Button BtnFechar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label LblEstoque;
        private System.Windows.Forms.ComboBox CpxCliente;
        private System.Windows.Forms.ComboBox CpxProduto;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TxtTotal;
    }
}