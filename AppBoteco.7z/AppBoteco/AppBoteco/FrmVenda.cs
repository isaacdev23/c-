﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppBoteco
{
    public partial class FrmVenda : Form
    {    
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Programas\\AppBoteco\\AppBoteco\\DbBoteco.mdf;Integrated Security=True");
    
        public FrmVenda()
        {
            InitializeComponent();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void CarregaCpxCliente()
        {
            string cli = "SELECT Id, nome FROM Cliente";
            SqlCommand cmd = new SqlCommand(cli, con);
            con.Open();
            cmd.CommandType = CommandType.Text; 
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cli, con);
            DataSet ds = new DataSet(); 
            dataAdapter.Fill(ds, "cliente");
            CpxCliente.ValueMember = "Id";
            CpxCliente.DisplayMember = "Name";
            CpxCliente.DataSource = ds.Tables["cliente"];
            con.Close();
        }
    }
}
